<?php
/**
 * All setup functionalities.
 *
 * @since 1.0
 */
load_theme_textdomain('aquene', get_template_directory() . '/languages');
if (!function_exists('aquene_setup')) :
    function aquene_setup()
    {
        /*
         * Make theme available for translation.
         * Translations can be filed in the /languages/ directory.
         */
        load_theme_textdomain('aquene', get_template_directory() . '/languages');

        // Add default posts and comments RSS feed links to head
        add_theme_support('automatic-feed-links');

        // This theme uses Featured Images (also known as post thumbnails) for per-post/per-page.
        add_theme_support('post-thumbnails');

        // Supporting title tag via add_theme_support (since WordPress 4.1)
        add_theme_support('title-tag');

        // Adds the support for the Custom Logo introduced in WordPress 4.5
        add_theme_support('custom-logo',
            array(
                'height' => '100',
                'width' => '100',
                'flex-width' => true,
                'flex-height' => true,
            )
        );

        // Registering navigation menus.
        register_nav_menus(array(
            'primary' => esc_html__('Primary Menu', 'aquene'),
            'footer' => esc_html__('Footer Menu', 'aquene')
        ));

        // Cropping the images to different sizes to be used in the theme
        add_image_size('featured-thumbnail', 200, 200, true);

        // Setup the WordPress core custom background feature.
        add_theme_support('custom-background', apply_filters('aquene_custom_background_args', array(
            'default-color' => 'eaeaea'
        )));

        // Adding excerpt option box for pages as well
        add_post_type_support('page', 'excerpt');
        /*
             * Enable support for Post Formats.
             *
             * See: https://codex.wordpress.org/Post_Formats
             */
//        add_theme_support( 'post-formats', array(
//            'aside', 'image', 'video', 'quote', 'link', 'gallery', 'status', 'audio', 'chat'
//        ) );
        /**
         * Switch default core markup for search form, comment form, and comments
         * to output valid HTML5.
         */
        add_theme_support('html5', array(
            'search-form',
            'comment-form',
            'comment-list',
            'gallery',
            'caption',
        ));

        // Support for selective refresh widgets in Customizer
        add_theme_support('customize-selective-refresh-widgets');

    }
endif;
add_action('after_setup_theme', 'aquene_setup');


/**
 * Define Directory Location Constants
 */
define('AQUENE_PARENT_DIR', get_template_directory());
define('AQUENE_CHILD_DIR', get_stylesheet_directory());

define('AQUENE_INCLUDES_DIR', AQUENE_PARENT_DIR . '/inc');
define('AQUENE_CSS_DIR', AQUENE_PARENT_DIR . '/css');
define('AQUENE_JS_DIR', AQUENE_PARENT_DIR . '/js');
define('AQUENE_LANGUAGES_DIR', AQUENE_PARENT_DIR . '/languages');

define('AQUENE_ADMIN_DIR', AQUENE_INCLUDES_DIR . '/admin');
define('AQUENE_WIDGETS_DIR', AQUENE_INCLUDES_DIR . '/widgets');
define('AQUENE_DEMO_DIR', AQUENE_INCLUDES_DIR . '/data-demo');

define('AQUENE_ADMIN_IMAGES_DIR', AQUENE_ADMIN_DIR . '/images');
define('AQUENE_ADMIN_CSS_DIR', AQUENE_ADMIN_DIR . '/css');
/**
 * Define URL Location Constants
 */
define('AQUENE_PARENT_URL', get_template_directory_uri());
define('AQUENE_CHILD_URL', get_stylesheet_directory_uri());

define('AQUENE_INCLUDES_URL', AQUENE_PARENT_URL . '/inc');
define('AQUENE_CSS_URL', AQUENE_PARENT_URL . '/css');
define('AQUENE_JS_URL', AQUENE_PARENT_URL . '/js');
define('AQUENE_LANGUAGES_URL', AQUENE_PARENT_URL . '/languages');

define('AQUENE_ADMIN_URL', AQUENE_INCLUDES_URL . '/admin');
define('AQUENE_WIDGETS_URL', AQUENE_INCLUDES_URL . '/widgets');


define('AQUENE_ADMIN_IMAGES_URL', AQUENE_ADMIN_URL . '/images');
define('AQUENE_ADMIN_CSS_URL', AQUENE_ADMIN_URL . '/css');

/** Load functions */
require_once AQUENE_INCLUDES_DIR . '/functions.php';
require_once AQUENE_INCLUDES_DIR . '/customizer.php';

/** Load Widgets and Widgetized Area */
require_once AQUENE_WIDGETS_DIR . '/widgets.php';


/**
 * Load Demo Importer Configs.
 */

require_once AQUENE_DEMO_DIR . '/demo-config.php';

/**
 * Load TGMPA Configs.
 */
require_once AQUENE_INCLUDES_DIR . '/tgm-plugin-activation/class-tgm-plugin-activation.php';
require_once AQUENE_INCLUDES_DIR . '/tgm-plugin-activation/tgmpa-aquene.php';

/**
 * Assign the AQUENE version to a variable.
 */
$theme = wp_get_theme('aquene');
$AQUENE_version = $theme['Version'];

