/**
 * Created by linhitdcn on 5/5/2018.
 */
"use strict";
function loadMore(obj) {
    var button = $(obj), loader = $('.infinite-loader'),
        data = {
            'action': 'loadmore',
           // 'query': aquene_loadmore_params.posts, // that's how we get params from wp_localize_script() function
            'page' : aquene_loadmore_params.current_page,
            'posts_per_page' : aquene_loadmore_params.posts_per_page,
            'cat' : aquene_loadmore_params.cat
        };

    $.ajax({
        url : infiniteScroll.settings.ajaxurl, // AJAX handler
        data : data,
        type : 'POST',
        beforeSend : function ( xhr ) {
            loader.show();
        },
        success : function( data ){
            if( data ) {
                button.prev().before(data); // insert new posts
                aquene_loadmore_params.current_page++;
                var max_page = Math.ceil(aquene_loadmore_params.found_posts / aquene_loadmore_params.posts_per_page);
                if ( max_page == aquene_loadmore_params.current_page ){
                    button.remove(); // if last page, remove the button
                }
                loader.hide();
            } else {
                button.remove(); // if no data, remove the button as well
            }
        },
        error : function () {
            loader.hide();
        }
    });
}
