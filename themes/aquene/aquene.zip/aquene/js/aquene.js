/**
 * Created by linhitdcn on 5/2/2018.
 */
"use strict";
//var $ = jQuery.noConflict();
/*
 Handles additional functionalities of the theme.
 */
$(function () {
    //remove text a menu-social-menu-container
    $('div.menu-social-menu-container a').each(function() {
            $(this).html("");
    });
    if (document.getElementsByTagName('html')[0].getAttribute('dir') === 'rtl') {
        var htmlRTL = true;
    } else {
        var htmlRTL = false;
    }
    var documentBody = $('body');
    var browserWindow = $(window);
    var pageContainer = $('#page');
    var headerContainer = pageContainer.find('#masthead');
    var contentContainer = pageContainer.find('#content');
    var adminBar = $('#wpadminbar');
    // Add custom class to table element and make it responsive.
        $('table').addClass('table').wrap('<div class="table-responsive" />');

        var infiniteCount = 0;

        documentBody.on('post-load', function () {

            infiniteCount = infiniteCount + 1;

            var infiniteItems = $('.infinite-wrap.infinite-view-' + infiniteCount);
            infiniteItems.find('table').addClass('table').wrap('<div class="table-responsive" />');
        });

    // Header search box.
    var searchContainer = pageContainer.find('#search-container');
    // Open search container.
    $('#header-search').on('click', function (e) {
        e.preventDefault();
        searchContainer.fadeIn('fast', function () {
            searchContainer.find('.search-field').focus();
        });
    });
    if (adminBar.is(':visible')) {
        searchContainer.css('top', adminBar.height());

        browserWindow.on('resize', function () {
            searchContainer.css('top', adminBar.height());
        });
    }
    // Close search container.
    pageContainer.find('close-search-container').on('click', function (e) {
        e.preventDefault();
        searchContainer.fadeOut('fast');
    });

    // Close search container if user clicks outside search form.
    documentBody.on('click', '#search-container', function (e) {
        var formContainer = searchContainer.find('.search-form');

        if (!formContainer.is(e.target) && formContainer.has(e.target).length === 0) {
            searchContainer.fadeOut('fast');
        }
    });

    // Mobile Menu.
    var mobileMenuContainer = $('#mobile-navigation');
    var jetpackSocialMenu = headerContainer.find('.jetpack-social-navigation');
    headerContainer.find('.header-left-col .menu').clone().appendTo('#mobile-navigation');

    if (jetpackSocialMenu.length) {
        jetpackSocialMenu.clone().appendTo('#mobile-navigation');
    } else {
        var defaultSocialMenu = headerContainer.find('.social-navigation');
        if (defaultSocialMenu.length) {
            defaultSocialMenu.clone().appendTo('#mobile-navigation');
        }
    }

    // Add dropdown toggle that displays child menu items.
    var dropdownToggle = $('<button />', {
        'class': 'dropdown-toggle clean-button has-icon',
        'aria-expanded': false
    }).append($('<span />', {
        'class': 'screen-reader-text',
        text: screenReaderText.expand
    }));

    var linkWithChildren = mobileMenuContainer.find('.menu-item-has-children > a');

    // Add toggle buttons.
    linkWithChildren.after(dropdownToggle);

    // Set height of toggle buttons.
    mobileMenuContainer.find('.dropdown-toggle').css('height', linkWithChildren.outerHeight() + 'px');

    // Toggle buttons and submenu items with active children menu items.
    mobileMenuContainer.find('.current-menu-ancestor > button').addClass('toggled-on');
    mobileMenuContainer.find('.current-menu-ancestor > .sub-menu').addClass('toggled-on');

    // Add menu items with submenus to aria-haspopup="true".
    mobileMenuContainer.find('.menu-item-has-children').attr('aria-haspopup', 'true');

    mobileMenuContainer.find('.dropdown-toggle').click(function (e) {
        var _this = $(this),
            screenReaderSpan = _this.find('.screen-reader-text');

        e.preventDefault();
        _this.toggleClass('toggled-on');
        _this.next('.children, .sub-menu').toggleClass('toggled-on');

        // jscs:disable
        _this.attr('aria-expanded', _this.attr('aria-expanded') === 'false' ? 'true' : 'false');
        // jscs:enable
        screenReaderSpan.text(screenReaderSpan.text() === screenReaderText.expand ? screenReaderText.collapse : screenReaderText.expand);
    });

    var bigSlideAPI = headerContainer.find('.mobile-menu').bigSlide({
        menu: ( '#toggle-sidebar' ),
        side: htmlRTL ? 'left' : 'right',
        menuWidth: '340px',
        afterOpen: function () {
            documentBody.addClass('toggle-sidebar-active');
            jQuery(bigSlideAPI.settings.menu).attr('aria-hidden', 'false');
        },
        afterClose: function () {
            documentBody.removeClass('toggle-sidebar-active');
            jQuery(bigSlideAPI.settings.menu).attr('aria-hidden', 'true');
        },
    }).bigSlideAPI;

    jQuery(document.getElementById('close-toggle-sidebar')).on('click', function (e) {
        e.preventDefault();
        bigSlideAPI.view.toggleClose();
    });

    // Fixed Header.
    var stickyHeader = headerContainer.find('#sticky-header');
    var headerContainerTop = headerContainer.outerHeight();


    if (adminBar.is(':visible')) {
        stickyHeader.css('top', adminBar.height());

        browserWindow.on('resize', function () {
            stickyHeader.css('top', adminBar.height());
        });
    }

    if (documentBody.hasClass('single')) {
        var currentArticle = pageContainer.find('.hentry');
        var articleHeight = currentArticle.outerHeight(true);
        var articlePossition = currentArticle.offset().top + articleHeight;

        stickyHeader.find('.sticky-left-col').prepend('<div class="hentry-title">' + currentArticle.find('.entry-title').text());
        stickyHeader.prepend('<div id="reading-progress" class="progress-bar"></div>');

        var headerProgressBar = $('#reading-progress');

        var makeHeaderSticky = function () {
            var scrollTop = browserWindow.scrollTop();

            if (scrollTop > headerContainerTop) {
                stickyHeader.addClass('scroll-header');
                if (scrollTop <= articlePossition) {
                    headerProgressBar.css({'width': Math.ceil(( scrollTop / articleHeight ) * 100) + '%'}) ;
                } else {
                    headerProgressBar.css({'width': '100%'}) ;
                }

            } else {
                stickyHeader.removeClass('scroll-header');
            }
        };

    } else {
        headerContainer.find('.site-navigation').clone().removeAttr('id').prependTo('.sticky-left-col');

        var makeHeaderSticky = function () {
            if (browserWindow.scrollTop() > headerContainerTop) {
                stickyHeader.addClass('scroll-header');
            } else {
                stickyHeader.removeClass('scroll-header');
            }
        };
    }

    makeHeaderSticky();

    browserWindow.on('scroll', function () {
        makeHeaderSticky();
    });

    // Go to the top.
    $('#gotop').on('click', function (e) {
        e.preventDefault();

        $('body, html').animate({
            scrollTop: 0
        }, 800);
    });
});