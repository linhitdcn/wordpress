<?php
/**
 * Theme Single Post Section for our theme.
 *
 * @package ThemeGrill
 * @subpackage Spacious
 * @since Spacious 1.0
 */
get_header(); ?>
<?php
global $post;
$category = get_the_category();
$cat_name = !empty($category)? $category[0]->name: '';
?>
<div class="featured-image-wrap">
    <span class="featured-image has-background-cover"
          style="background-image: url(<?php echo esc_url(get_the_post_thumbnail_url(get_the_ID())) ?>)"></span>
</div>
<div id="primary" class="content-area">
    <main id="main" class="site-main" role="main">
        <article id="post-<?php echo get_the_ID() ?>"
                 class="post type-post status-publish format-standard has-post-thumbnail hentry">
            <header class="entry-header hentry-wrapper">
                <div class="entry-cats">
                    <?php if(!empty($cat_name)): ?>
                    <a href="http://demo.themesharbor.com/aquene/category/lifestyle/"
                                           rel="category tag"><?php echo $cat_name ?> </a>
                    <?php endif; ?>
                </div>
                <h1 class="entry-title"><?php single_post_title(); ?></h1>
                <div class="entry-meta clear">
                    <?php echo get_avatar($post->post_author, 96, '', '', array('class' => 'avatar photo', 'id' => '')); ?>
                    <div class="inner-meta"><span class="byline"> By <a class="url fn n"
                                                                        href="<?php echo get_author_posts_url($post->post_author); ?>"><?php echo get_the_author_meta('display_name', $post->post_author) ?></a></span>
                        <span class="posted-on"><a
                                href="<?php echo get_permalink($post->ID); ?>"
                                rel="bookmark"><time class="entry-date published"
                                                     datetime="<?php echo get_the_time('c', get_the_ID()); ?>"><?php echo get_the_date(); ?></time><time
                                    class="updated"
                                    datetime="<?php echo get_the_modified_date('c', get_the_ID()); ?>"><?php echo get_the_modified_date(); ?></time></a></span>
                    </div>
                    <div class="comments-link has-icon"><a
                            href="<?php echo get_permalink($post->ID); ?>#respond">Leave
                            a Comment<span class="screen-reader-text"><?php single_post_title(); ?></span></a>
                    </div> <!-- .comments-link -->
                </div><!-- .entry-meta -->
            </header>
            <div class="hentry-inner hentry-wrapper">
                <?php if (has_excerpt(get_the_ID())): ?>
                    <div class="entry-summary">
                        <?php echo get_the_excerpt(get_the_ID()); ?>
                    </div>
                <?php endif; ?>
                <div class="entry-content">
                    <?php
                    if (have_posts()):
                        while (have_posts()) : the_post();
                            the_content();
                        endwhile;
                    endif;
                    wp_reset_query();
                    ?>
                    <div class="page-links">
                        <?php
                        $defaults = array(
                            'before' => '<span class="page-links-title">Pages:</span>',
                            'after' => '',
                            'link_before' => '<span><span class="screen-reader-text">Page </span>',
                            'link_after' => '</span>',
                            'next_or_number' => 'number',
                            'separator' => '<span class="screen-reader-text">, </span>',
                            'nextpagelink' => __('Next page', 'twentyfourteen'),
                            'previouspagelink' => __('Previous page', 'twentyfourteen'),
                            'pagelink' => '%',
                            'echo' => 1
                        );
                        wp_link_pages($defaults);
                        ?></div>
                    <div id="jp-relatedposts" class="jp-relatedposts" style="display: block;">
                        <h3 class="jp-relatedposts-headline"><em><?php echo __('you might also like', 'aquene') ?>
                                :</em></h3>
                        <div class="jp-relatedposts-items jp-relatedposts-items-visual jp-relatedposts-list ">
                            <?php
                            //var_dump($category);die();
                            $args = array(
                                'numberposts' => 3,
                                'exclude' => array($post->ID),
                                //'category' => $category->term_id,
                                'orderby' => 'date',
                                'order' => 'DESC',
                                'post_status' => 'publish'
                            );
                            $related = get_posts($args);
                            if ($related) foreach ($related as $post):
                                setup_postdata($post);
                                $category = get_the_category($post->ID);
                                $first_category = $category[0];

                                ?>
                                <div class="jp-relatedposts-post jp-relatedposts-post0 jp-relatedposts-post-thumbs"
                                     data-post-id="<?php the_ID() ?>" data-post-format="false"><a
                                        class="jp-relatedposts-post-a"
                                        href="<?php the_permalink() ?>"
                                        title="<?php echo get_the_excerpt($post->ID) ?>"
                                        rel="nofollow" data-origin="94"
                                        data-position="0">
                                        <?php if (has_post_thumbnail()): ?>
                                            <?php echo get_the_post_thumbnail($post->ID, array(350, 200), array('class' => 'jp-relatedposts-post-img')); ?>
                                        <?php else: ?>
                                            <img src="http://via.placeholder.com/350x200"
                                                 class="jp-relatedposts-post-img" title="<?php the_title() ?>"
                                                 alt="<?php the_title() ?>"/>
                                        <?php endif; ?>
                                    </a>
                                    <h4
                                        class="jp-relatedposts-post-title"><a class="jp-relatedposts-post-a"
                                                                              href="<?php the_permalink() ?>"
                                                                              title="<?php echo get_the_excerpt($post->ID) ?>"
                                                                              rel="nofollow" data-origin="94"
                                                                              data-position="0"><?php the_title() ?></a>
                                    </h4>
                                    <p class="jp-relatedposts-post-date"
                                       style="display: block;"><?php echo get_the_date(); ?></p>
                                    <p class="jp-relatedposts-post-context">In "<?php echo $first_category->name ?>"</p>
                                </div>
                            <?php endforeach;
                            wp_reset_postdata(); ?>
                        </div>
                    </div>
                </div>
                <div class="entry-footer">
                    <div class="entry-tags">
                        <?php if (has_tag('', $post->ID)): ?>
                            <span class="links-meta">Tags:</span>
                            <?php echo get_the_tag_list() ?>
                        <?php endif; ?>
                    </div>
                    <div class="entry-author">
                        <div class="author-avatar">
                            <?php echo get_avatar($post->post_author, 352, '', '', array('class' => 'avatar avatar-352 photo grav-hashed grav-hijack', 'id' => '')); ?>
                        </div><!-- .author-avatar -->

                        <div class="author-heading">
                            <h2 class="author-title">Published by <span
                                    class="author-name"><?php echo get_the_author_meta('display_name', $post->post_author) ?></span>
                            </h2>
                        </div><!-- .author-heading -->

                        <p class="author-bio">
                            <?php echo get_the_author_meta('description', $post->post_author) ?>
                            <a class="author-link" href="<?php echo get_author_posts_url($post->post_author); ?>"
                               rel="author">
                                View all posts by <?php echo get_the_author_meta('display_name', $post->post_author) ?> </a>
                        </p><!-- .author-bio -->
                    </div>
                </div>
            </div>
        </article>
        <?php
        // comments are open or we have at least one comment, load up the comment template.
        if (comments_open() || get_comments_number()) :
            comments_template();
        endif;
        ?>
    </main>
</div>
<?php
// Previous/next post navigation.
// Start the loop.
while (have_posts()) : the_post();
    the_post_navigation(array(
        'next_text' => '<span class="nav-meta" aria-hidden="true">' . __('Next Entry', 'aquene') . '</span> ' .
            '<span class="nav-title">%title</span>',
        'prev_text' => '<span class="nav-meta" aria-hidden="true">' . __('Previous Entry', 'aquene') . '</span> ' .
            '<span class="nav-title">%title</span>',
    ));
endwhile;
?>
<?php get_footer(); ?>
