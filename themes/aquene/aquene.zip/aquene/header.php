<!DOCTYPE html>
<html>
<head>
    <meta charset="<?php bloginfo('charset'); ?>"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="http://gmpg.org/xfn/11"/>
    <link rel="pingback" href="<?php bloginfo('pingback_url'); ?>"/>
    <script type="text/javascript">
        //<![CDATA[
        var infiniteScroll = {
            "settings": {
                "ajaxurl": "<?php echo site_url() . '/wp-admin/admin-ajax.php'; ?>",
                "text": "Older posts",
                "totop": "Scroll back to top"
            }
        };
        var screenReaderText = {"expand": "Expand child menu", "collapse": "Collapse child menu"};
        //]]>
    </script>
    <?php
    /**
     * This hook is important for wordpress plugins and other many things
     */
    wp_head();
    ?>
</head>
<body <?php body_class(); ?>>
<div id="page" class="site container">
    <a class="skip-link screen-reader-text" href="#content">Skip to content</a>
    <div id="search-container" role="dialog">
        <button type="button" id="close-search-container" class="clean-button has-icon"><span
                class="screen-reader-text">Close</span></button>

        <form role="search" method="get" class="search-form" action="<?php echo esc_url(home_url()); ?>">
            <label for="search-form-5ae9989cd8537">
                <span class="screen-reader-text"><?php echo __('Search for', 'aquene')?>:</span>
                <input type="search" id="search-form-5ae9989cd8537" class="search-field"
                       placeholder="<?php echo __('Search this website', 'aquene')?>…" value="" name="s" title="Search for:">
            </label>
            <button type="submit" class="submit has-icon clean-button"><span class="screen-reader-text"><?php echo __('Search', 'aquene') ?></span>
            </button>
        </form><!-- .search-form -->
    </div>
    <!-- #search-container -->
    <div id="toggle-sidebar" aria-hidden="true"
         style="position: fixed; top: 0px; bottom: 0px; height: 100%; right: -340px; width: 340px; transition: right 300ms ease;">
        <div class="inner-panel">
            <button id="close-toggle-sidebar" class="has-icon">Close Menu</button>
            <nav id="mobile-navigation" class="mobile-navigation" role="navigation" aria-label="Mobile Navigation">
            </nav><!-- #mobile-navigation -->
        </div><!-- .inner-panel -->
    </div>
    <!-- #toggle-sidebar -->
    <header id="masthead" class="site-header clear" role="banner">
        <div class="header-left-col">
            <div class="site-branding">
                <h1 class="site-title" id="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>"><?php bloginfo( 'name' ); ?></a></h1>
                <p class="site-description">The latest news around the world.</p>
            </div><!-- .site-branding -->

            <nav id="site-navigation" class="site-navigation main-navigation" role="navigation">
                <?php
                if (has_nav_menu('primary')) {
                    wp_nav_menu(array(
                        'theme_location' => 'primary',
                        'container_class' => 'menu-main-menu-container'
                    ));
                }
                ?>
            </nav><!-- #site-navigation -->

        </div><!-- .header-left-col -->

        <div class="header-right-col">
            <button id="header-search" class="has-icon clean-button">
                <span class="screen-reader-text">Search</span>
            </button><!-- #header-search -->

            <nav class="jetpack-social-navigation jetpack-social-navigation-genericons" role="navigation"
                 aria-label="Social Links Menu">
                <?php
                if (has_nav_menu('social')) {
                    wp_nav_menu(array(
                        'menu'=> 'Aquene Social Menu',
                       // 'theme_location' => 'footer',
                      //  'walker' => new description_walker(),
                        'container_class' => 'menu-social-menu-container'
                    ));
                }
                ?>
            </nav><!-- .jetpack-social-navigation -->

            <button id="static-menu" class="has-icon mobile-menu clean-button">Menu</button>
        </div><!-- .header-right-col -->

        <div id="sticky-header" class="clear">
            <div class="sticky-left-col">
                <button id="sticky-menu" class="has-icon mobile-menu clean-button">Menu</button>
            </div><!-- .sticky-left-col -->

            <div class="sticky-right-col">
                <button id="gotop" class="has-icon clean-button primary-font"><?php echo __('Back to Top','aquene') ?></button>
            </div><!-- .sticky-right-col -->
        </div><!-- #sticky-header -->
    </header>
    <div id="content" class="site-content">

