<?php

/**
 * Register jquery scripts
 */
function aquene_scripts_styles_method()
{
    /**
     * Loads our main stylesheet.
     */
    // Enqueue style.
    wp_enqueue_style('google_fonts', '//fonts.googleapis.com/css?family=Lato');
    wp_enqueue_style('aquene-font-awesome', get_template_directory_uri() . '/font-awesome/css/font-awesome.min.css', array());
    wp_enqueue_style('aquene_style', get_stylesheet_uri(), array(), time());
    wp_enqueue_style('aquene_mediaelement', includes_url('js/mediaelement/wp-mediaelement.min.css'), array());
    if (is_single()) {
        wp_enqueue_style('aquene_related', get_template_directory_uri() . '/css/related.css', array(), time());
    }
    // Enqueue script.
    /**
     * Adds JavaScript to pages with the comment form to support
     * sites with threaded comments (when in use).
     */
    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
    wp_enqueue_script('jquery');
    wp_enqueue_script('aquene-mediaelement', includes_url('js/mediaelement/mediaelement-and-player.min.js'), array(), '4.2');
    wp_enqueue_script('aquene-custom', get_template_directory_uri() . '/js/aquene.js', array(), time());
    wp_enqueue_script('aquene-navigation', get_template_directory_uri() . '/js/navigation.js', array(), time());
    wp_enqueue_script('aquene-big-slide', get_template_directory_uri() . '/js/big-slide.js', array(), time());

}

add_action('wp_enqueue_scripts', 'aquene_scripts_styles_method');
/****************************************************************************************/
/**
 * Show list post latest
 */
if (!function_exists('qrPost')):
    function qrPost($posts_per_page, $paged, $cat)
    {
        $args = array(
            'posts_per_page' => $posts_per_page,
            'paged' => $paged,
            'cat' => $cat,
            'orderby' => 'date',
            'order' => 'DESC',
            'post_status' => 'publish'
        );
        query_posts($args);
    }
endif;
add_action('qrPost', 'qrPost', 10, 3);

function aquene_loadmore_ajax_handler()
{
    // prepare our arguments for the query
    $posts_per_page = $_POST['posts_per_page'];
    $cat = $_POST['cat'];
    $paged = $_POST['page'] + 1;
    do_action('qrPost', $posts_per_page, $paged, $cat);
    if (have_posts()) :
        // run the loop
        while (have_posts()): the_post();
            // look into your theme code how the posts are inserted, but you can use your own HTML of course
            // do you remember? - my example is adapted for Twenty Seventeen theme
            get_template_part('content');
            // for the test purposes comment the line above and uncomment the below one
            // the_title();
        endwhile;
    endif;
    die; // here we exit the script and even no wp_reset_query() required!
}

add_action('wp_ajax_loadmore', 'aquene_loadmore_ajax_handler'); // wp_ajax_{action}
add_action('wp_ajax_nopriv_loadmore', 'aquene_loadmore_ajax_handler'); // wp_ajax_nopriv_{action}

function aquene_my_load_more_scripts()
{
    global $wp_query;
    // In most cases it is already included on the page and this line can be removed
    wp_enqueue_script('jquery');
    // register our main script but do not enqueue it yet
    wp_register_script('my_loadmore', get_template_directory_uri() . '/js/myloadmore.js', array('jquery'), time());
    // now the most interesting part
    // we have to pass parameters to myloadmore.js script but we can get the parameters values only in PHP
    // you can define variables directly in your HTML but I decided that the most proper way is wp_localize_script()
    wp_localize_script('my_loadmore', 'aquene_loadmore_params', array(
        //  'ajaxurl' => site_url() . '/wp-admin/admin-ajax.php', // WordPress AJAX
        //  'posts' => json_encode( $wp_query->query_vars ), // everything about your loop is here
        'current_page' => get_query_var('paged') ? get_query_var('paged') : 1,
        'posts_per_page' => get_option('posts_per_page') ? get_option('posts_per_page') : 6,
        'found_posts' => $wp_query->found_posts,
        'cat' => get_query_var('cat')
    ));
    wp_enqueue_script('my_loadmore');
}

add_action('wp_enqueue_scripts', 'aquene_my_load_more_scripts');

/**
 * Add featured image as background image to post navigation elements.
 *
 * @since aquene 1.0
 *
 * @see wp_add_inline_style()
 */
function aquene_post_nav_background()
{
    if (!is_single()) {
        return;
    }

    $previous = (is_attachment()) ? get_post(get_post()->post_parent) : get_adjacent_post(false, '', true);
    $next = get_adjacent_post(false, '', false);
    $css = '';

    if (is_attachment() && 'attachment' == $previous->post_type) {
        return;
    }
    if ($previous && has_post_thumbnail($previous->ID)) {

        $prevthumb = wp_get_attachment_image_src(get_post_thumbnail_id($previous->ID), 'post-thumbnail');
        $css .= '
			.post-navigation .nav-previous a:before {content: ""; background-image: url(' . esc_url($prevthumb[0]) . '); }
		';
    }

    if ($next && has_post_thumbnail($next->ID)) {
        $nextthumb = wp_get_attachment_image_src(get_post_thumbnail_id($next->ID), 'post-thumbnail');
        $css .= '
			.post-navigation .nav-next a:before {content: ""; background-image: url(' . esc_url($nextthumb[0]) . ');}
		';
    }
    // var_dump($css);die();
    wp_add_inline_style('aquene_style', $css);
}

add_action('wp_enqueue_scripts', 'aquene_post_nav_background');
/**
 * Filter the body_class
 *
 * Throwing different body class for the different layouts in the body tag
 */
function aquene_body_class($classes)
{
    global $post;

    if (is_home() || is_category()) {
        $classes[] = 'infinite-scroll hfeed';
    }

    return $classes;
}

add_filter('body_class', 'aquene_body_class');
