<?php
/**
 * Aquene Theme Customizer
 *
 * @package    Lihnitdcn
 * @subpackage Aquene
 * @since      Aquene 1.0
 */
function aquene_customize_register($wp_customize)
{
// Transport postMessage variable set
    $customizer_selective_refresh = isset($wp_customize->selective_refresh) ? 'postMessage' : 'refresh';

    $wp_customize->get_setting('blogname')->transport = 'postMessage';
    $wp_customize->get_setting('blogdescription')->transport = 'postMessage';
    $wp_customize->get_setting('header_textcolor')->transport = 'postMessage';

    if (isset($wp_customize->selective_refresh)) {
        $wp_customize->selective_refresh->add_partial('blogname', array(
            'selector' => '#site-title a',
            'render_callback' => 'aquene_customize_partial_blogname',
        ));

        $wp_customize->selective_refresh->add_partial('blogdescription', array(
            'selector' => '#site-description',
            'render_callback' => 'aquene_customize_partial_blogdescription',
        ));
    }

    /*
     * Assigning the theme name
     */
    $aquene_themename = get_option( 'stylesheet' );
    $aquene_themename = preg_replace( "/\W/", "_", strtolower( $aquene_themename ) );

    /****************************************Start of the content show Options****************************************/
    // content show option
    $wp_customize->add_section( 'aquene_main_content_section', array(
        'priority' => 220,
        'title'    => __( 'Main Content', 'aquene' )
    ) );
    $wp_customize->add_setting('posts_per_page', array(
        'default'           => get_option( 'posts_per_page' ),
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
    ) );
    $wp_customize->add_control( 'posts_per_page', array(
        'type'     => 'number',
        'priority' => 1,
        'label'    => __( 'Blog pages show at most', 'aquene' ),
        'section'  => 'aquene_main_content_section',
        'input_attrs'=> array('min'=>6, 'step'=>3)
    ) );
    $wp_customize->add_setting('aquene_text_older_posts', array(
        'default'           => 'Older posts',
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
    ) );
   $wp_customize->add_control( 'aquene_text_older_posts', array(
        'type'     => 'text',
        'priority' => 2,
        'label'    => __( 'Text older posts', 'aquene' ),
        'section'  => 'aquene_main_content_section',
    ) );

    // Selective refresh for slider activate
    if ( isset( $wp_customize->selective_refresh ) ) {
        $wp_customize->selective_refresh->add_partial( 'posts_per_page', array(
            'selector'        => '#main',
            'render_callback' => '',
        ) );
        $wp_customize->selective_refresh->add_partial( 'aquene_text_older_posts', array(
            'selector'        => '#customize-partial-edit-shortcut-older-posts',
            'render_callback' => '',
        ) );
    }
}
add_action( 'customize_register', 'aquene_customize_register' );
/*****************************************************************************************/

/**
 * Render the site title for the selective refresh partial.
 *
 * @return void
 */
function aquene_customize_partial_blogname() {
    bloginfo( 'name' );
}

/**
 * Render the site tagline for the selective refresh partial.
 *
 * @return void
 */
function aquene_customize_partial_blogdescription() {
    bloginfo( 'description' );
}

/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 *
 * @since aquene 1.4.9
 */
function aquene_customize_preview_js() {
    wp_enqueue_script( 'aquene-customizer', get_template_directory_uri() . '/js/customizer.js', array( 'customize-preview' ), time(), true );
}

add_action( 'customize_preview_init', 'aquene_customize_preview_js' );

/*****************************************************************************************/
?>