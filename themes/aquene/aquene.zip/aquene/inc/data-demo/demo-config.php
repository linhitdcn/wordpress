<?php
/**
 * functions for configuring demo importer.
 *
 * @author   themegrill
 * @category admin
 * @package  importer/functions
 * @version  1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * enqueue scripts.
 */
function enqueue_scripts()
{
    $screen = get_current_screen();
    $screen_id = $screen ? $screen->id : '';
    // register admin styles.
    if ('appearance_page_demo-importer' === $screen_id) {
        wp_enqueue_style('demo-importer', AQUENE_CSS_URL . '/admin/demo-importer.css', array(), time());
    }
}

add_action('admin_enqueue_scripts', 'enqueue_scripts');

/**
 * setup demo importer packages.
 *
 * @param  array $packages
 *
 * @return array
 */
function aquene_demo_importer_packages($packages)
{
    $new_packages = array(
        'aquene' => array(
            'name' => __('aquene', 'aquene'),
            'screenshot' => get_template_directory_uri() . '/screenshot.png',
            'author' => __('linhitdcn', 'aquene'),
            'actions' => array(
                'preview_url' => 'http://demo.themesharbor.com/aquene/',
                'download_url' => 'https://github.com/linhitdcn/wordpress/raw/master/themes/aquene/data-aquene.zip'
            ),
        )
    );

    return array_merge($new_packages, $packages);
}

add_filter('demo_importer_packages', 'aquene_demo_importer_packages');
/**
 * demo importer page output.
 */
function demo_importer()
{
    $demos = apply_filters('demo_importer_packages', array());
    include_once(AQUENE_ADMIN_DIR . "/views/html-admin-page-importer.php");
}

/**
 * add menu item.
 */
function admin_menu()
{
    add_theme_page(__('theme demo', 'aquene'), __('theme demo', 'aquene'), 'switch_themes', 'demo-importer', 'demo_importer');
}

add_action('admin_menu', 'admin_menu');

