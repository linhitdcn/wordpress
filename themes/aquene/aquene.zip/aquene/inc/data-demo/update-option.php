<?php
session_start();
/**
 * Update option sidebars_widgets.
 */
function archives($widget_id, $depth)
{
    $arr = array($widget_id => array('title' => '', 'count' => 1, 'dropdown' => 0));
    if ($depth > 1 && !empty($_SESSION['archives'])) {
        $_SESSION['archives'] = $_SESSION['archives'] + $arr;
    } else {
        $_SESSION['archives'] = $arr + array('_multiwidget' => 1);
    }
    return $_SESSION['archives'];
}

function categories($widget_id, $depth)
{
    $arr = array($widget_id => array('title' => '', 'count' => 1, 'dropdown' => 0, 'hierarchical' => 0));
    if ($depth > 1 && !empty($_SESSION['categories'])) {
        $_SESSION['categories'] = $_SESSION['categories'] + $arr;
    } else {
        $_SESSION['categories'] = $arr + array('_multiwidget' => 1);
    }
    return $_SESSION['categories'];
}

function nav_menu($widget_id, $depth)
{
    $arr = array($widget_id => array('title'=>'Custom Menu', 'nav_menu' => 134));
    if ($depth > 1 && !empty($_SESSION['nav_menu'])) {
        $_SESSION['nav_menu'] = $_SESSION['nav_menu'] + $arr;
    } else {
        $_SESSION['nav_menu'] = $arr + array('_multiwidget' => 1);
    }
    return $_SESSION['nav_menu'];
}

function recent_posts($widget_id, $depth)
{
    $arr = array($widget_id => array('title' => '', 'number' => 4, 'show_date' => true));
    if ($depth > 1 && !empty($_SESSION['recent_posts'])) {
        $_SESSION['recent_posts'] = $_SESSION['recent_posts'] + $arr;
    } else {
        $_SESSION['recent_posts'] = $arr + array('_multiwidget' => 1);
    }
    return $_SESSION['recent_posts'];
}

function aquene_primary_section_widget($widget_id, $depth)
{
    $arr = array($widget_id => array('post1' => 830, 'post2' => 828));
    if ($depth > 1 && !empty($_SESSION['aquene_primary_section_widget'])) {
        $_SESSION['aquene_primary_section_widget'] = $_SESSION['aquene_primary_section_widget'] + $arr;
    } else {
        $_SESSION['aquene_primary_section_widget'] = $arr + array('_multiwidget' => 1);
    }
    return $_SESSION['aquene_primary_section_widget'];
}

function aquene_secondary_section_widget($widget_id, $depth)
{
    $arr = array($widget_id => array('page_id0' => 808, 'page_id1' => 780, 'page_id2' => 795));
    if ($depth > 1 && !empty($_SESSION['aquene_featured_content_bottom'])) {
        $_SESSION['aquene_secondary_section_widget'] = $_SESSION['aquene_secondary_section_widget'] + $arr;
    } else {
        $_SESSION['aquene_secondary_section_widget'] = $arr + array('_multiwidget' => 1);
    }
    return $_SESSION['aquene_secondary_section_widget'];
}

function custom_html($widget_id, $depth)
{
    $content = '<p class="site-footer-title"><a href="http://demo.themesharbor.com/aquene/" rel="home">Aquene</a></p><p class="site-footer-description">The latest news around the world.</p>';
    if ($widget_id == 3) {
        $content = '<a href="https://wordpress.org/">Proudly powered by WordPress</a> <span class="sep"> | </span>Theme: aquene by <a href="https://themesharbor.com/" rel="designer">Themes Harbor</a>';
    }
    $arr = array($widget_id => array('title' => '', 'content' => $content));
    if ($depth > 1 && !empty($_SESSION['custom_html'])) {
        $_SESSION['custom_html'] = $_SESSION['custom_html'] + $arr;
    } else {
        $_SESSION['custom_html'] = $arr + array('_multiwidget' => 1);
    }
    return $_SESSION['custom_html'];
}

//sidebars_widgets demo
function sidebars_widgets()
{
    $sidebars_widgets = array(
        'aquene_footer_sidebar_one' => array
        (
            'archives-3',
        ),
        'aquene_footer_sidebar_two' => array
        (
            'categories-3'
        ),
        'aquene_footer_sidebar_three' => array
        (
            'nav_menu-2'

        ),
        'aquene_footer_sidebar_four' => array
        (
            'recent-posts-2'
        ),
        'aquene_footer_site_title' => array
        (
            'custom_html-2'
        ),
        'aquene_footer_sidebar_site_info' => array
        (
            'custom_html-3'
        ),
        'aquene_featured_content_top' => array
        (
            'aquene_primary_section_widget-17'
        ),
        'aquene_featured_content_bottom' => array
        (
            'aquene_secondary_section_widget-2'
        ),
        'array_version' => 3
    );
    return $sidebars_widgets;
}

function update_widgets()
{
    //update option
    update_option('show_on_front', 'posts');
    update_option('blogname', 'Aquene');
    update_option('permalink_structure', '/%postname%/');

    $arr = sidebars_widgets();
//   update sidebars_widgets
    update_option('sidebars_widgets', $arr);
    $depth = array('archives' => 0, 'custom_html' => 0, 'categories' => 0, 'recent-posts' => 0, 'nav_menu' => 0, 'aquene_primary_section_widget' => 0, 'aquene_secondary_section_widget' => 0);
    foreach ($arr as $k => $val) {
        if (is_array($val)) {
            foreach ($val as $widget) {
                preg_match('/(?<widget_name>.*)-(?<widget_id>\d+)/i', $widget, $matches);
                $widget_name = $matches['widget_name'];
                $widget_id = $matches['widget_id'];
                $prefix_widget = 'widget_' . $widget_name;
                if (array_key_exists($widget_name, $depth)) {
                    $data = array();
                    $depth[$widget_name]++;
                    switch ($widget_name) {
                        case 'archives':
                            $data = archives($widget_id, $depth[$widget_name]);
                            break;
                        case 'categories':
                            $data = categories($widget_id, $depth[$widget_name]);
                            break;
                        case 'custom_html':
                            $data = custom_html($widget_id, $depth[$widget_name]);
                            break;
                        case 'nav_menu':
                            $data = nav_menu($widget_id, $depth[$widget_name]);
                            break;
                        case 'recent-posts':
                            $data = recent_posts($widget_id, $depth[$widget_name]);
                            break;
                        case 'aquene_primary_section_widget':
                            $data = aquene_primary_section_widget($widget_id, $depth[$widget_name]);
                            break;
                        case 'aquene_secondary_section_widget':
                            $data = aquene_secondary_section_widget($widget_id, $depth[$widget_name]);
                            break;
                    }
                    update_option($prefix_widget, $data);
                }
            }
        }
    }
}

add_action('after_switch_theme', 'update_widgets');
// destroy the session
session_unset();
session_destroy();