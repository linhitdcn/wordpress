<?php
/**
 * Contains all the functions related to sidebar and widget.
 *
 * @package    ThemeGrill
 * @subpackage aquene
 * @since      aquene 1.0
 */

add_action('widgets_init', 'aquene_widgets_init');
/**
 * Function to register the widget areas(sidebar) and widgets.
 */
function aquene_widgets_init()
{


    // Registering footer sidebar one
    register_sidebar(array(
        'name' => esc_html__('Aquene Footer Sidebar One', 'aquene'),
        'id' => 'aquene_footer_sidebar_one',
        'description' => esc_html__('Shows widgets at footer sidebar one.', 'aquene'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget' => '</section>',
        'before_title' => '<h3 class="widget-title"><span>',
        'after_title' => '</span></h3>',
    ));

    // Registering footer sidebar two
    register_sidebar(array(
        'name' => esc_html__('Aquene Footer Sidebar Two', 'aquene'),
        'id' => 'aquene_footer_sidebar_two',
        'description' => esc_html__('Shows widgets at footer sidebar two.', 'aquene'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget' => '</section>',
        'before_title' => '<h3 class="widget-title"><span>',
        'after_title' => '</span></h3>',
    ));

    // Registering footer sidebar three
    register_sidebar(array(
        'name' => esc_html__('Aquene Footer Sidebar Three', 'aquene'),
        'id' => 'aquene_footer_sidebar_three',
        'description' => esc_html__('Shows widgets at footer sidebar three.', 'aquene'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget' => '</section>',
        'before_title' => '<h3 class="widget-title"><span>',
        'after_title' => '</span></h3>',
    ));

    // Registering footer sidebar four
    register_sidebar(array(
        'name' => esc_html__('Aquene Footer Sidebar Four', 'aquene'),
        'id' => 'aquene_footer_sidebar_four',
        'description' => esc_html__('Shows widgets at footer sidebar four.', 'aquene'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget' => '</section>',
        'before_title' => '<h3 class="widget-title"><span>',
        'after_title' => '</span></h3>',
    ));
// Registering footer sidebar
    register_sidebar(array(
        'name' => esc_html__('Aquene Footer Site Title', 'aquene'),
        'id' => 'aquene_footer_site_title',
        'description' => esc_html__('Shows widgets at footer site title.', 'aquene'),
        'before_widget' => '<section>',
        'after_widget' => '</section>',
        'before_title' => '',
        'after_title' => '',
    ));
// Registering footer sidebar
    register_sidebar(array(
        'name' => esc_html__('Aquene Footer Site Info', 'aquene'),
        'id' => 'aquene_footer_sidebar_site_info',
        'description' => esc_html__('Shows widgets at footer site info.', 'aquene'),
        'before_widget' => '<section>',
        'after_widget' => '</section>',
        'before_title' => '',
        'after_title' => '',
    ));
    // Registering featured-content sidebar
    register_sidebar(array(
        'name' => esc_html__('Aquene Featured Content Top', 'aquene'),
        'id' => 'aquene_featured_content_top',
        'description' => esc_html__('Shows widgets at featured content top.', 'aquene'),
        'before_widget' => '<section>',
        'after_widget' => '</section>',
        'before_title' => '',
        'after_title' => '',
    ));
// Registering featured-content sidebar
    register_sidebar(array(
        'name' => esc_html__('Aquene Featured Content Bottom', 'aquene'),
        'id' => 'aquene_featured_content_bottom',
        'description' => esc_html__('Shows widgets at featured content bottom.', 'aquene'),
        'before_widget' => '<section>',
        'after_widget' => '</section>',
        'before_title' => '',
        'after_title' => '',
    ));

    // Registering widgets
    register_widget("aquene_primary_section_widget");
    register_widget("aquene_secondary_section_widget");

}

/****************************************************************************************/

/**
 * Featured service widget to show pages.
 */
class aquene_primary_section_widget extends WP_Widget
{
    function __construct()
    {
        $widget_ops = array(
            'classname' => 'widget_featured_block',
            'description' => __('Display Primary Section.', 'aquene'),
            'customize_selective_refresh' => true,
        );
        $control_ops = array('width' => 200, 'height' => 250);
        parent::__construct(false, $name = __('Aquene Primary Section', 'aquene'), $widget_ops, $control_ops);
    }

    function form($instance)
    {
        ?>
        <p>
            <label for="<?php echo $this->get_field_id('post1'); ?>"><?php _e('Post 1', 'aquene'); ?>:</label>
            <select style="width: 80%" name="<?php echo $this->get_field_name('post1') ?>" id="">
                <option value="0"><?php _e('&mdash; Select &mdash;'); ?></option>
                <?php
                do_action('qrPost', -1, 1, null);
                ?>
                <?php if (have_posts()) : ?>

                    <?php while (have_posts()) : the_post(); ?>

                        <option <?php echo ($instance['post1'] == get_the_ID()) ? 'selected' : '' ?>
                            value="<?php echo get_the_ID(); ?>"><?php echo get_the_title(); ?></option>

                    <?php endwhile; ?>

                <?php endif;
                wp_reset_query(); ?>
            </select>
            <label for="<?php echo $this->get_field_id('post2'); ?>"><?php _e('Post 2', 'aquene'); ?>:</label>
            <select style="width: 80%" name="<?php echo $this->get_field_name('post2') ?>" id="">
                <option value="0"><?php _e('&mdash; Select &mdash;'); ?></option>
                <?php
                do_action('qrPost', -1, 1, null);
                ?>
                <?php if (have_posts()) : ?>

                    <?php while (have_posts()) : the_post(); ?>

                        <option <?php echo ($instance['post2'] == get_the_ID()) ? 'selected' : '' ?>
                            value="<?php echo get_the_ID(); ?>"><?php echo get_the_title(); ?></option>

                    <?php endwhile; ?>

                <?php endif;
                wp_reset_query(); ?>
            </select>
        </p>
        <?php
    }

    function update($new_instance, $old_instance)
    {
        $instance = $old_instance;
        $instance['post1'] = absint($new_instance['post1']);
        $instance['post2'] = absint($new_instance['post2']);
        return $instance;
    }

    function widget($args, $instance)
    {
        extract($args);
        extract($instance);
        global $post;
        $post1 = (!empty($instance['post1'])) ? absint($instance['post1']) : 0;
        $post2 = (!empty($instance['post2'])) ? absint($instance['post2']) : 0;
        $postContent = new WP_Query(array(
            'p' => $post1,
        ));
        $postContent2 = new WP_Query(array(
            'p' => $post2,
        ));
       // var_dump($before_widget);die();
        echo $before_widget;
        ?>
        <?php
        while ($postContent->have_posts()): $postContent->the_post();
            $featured = get_the_post_thumbnail_url($post->ID);
            $category = get_the_category();
            $first_category = $category[0];
            ?>
            <article id="post-<?php echo $post->ID; ?>"
                     class="post-<?php echo $post->ID; ?> post type-post status-publish format-standard has-post-thumbnail hentry hentry-one category-lifestyle tag-colors tag-featured tag-international tag-style tag-tips">
                <a href="<?php echo esc_url(get_permalink()); ?>"
                   class="thumb-link ">
                <span class="featured-image has-background-cover has-animation"
                      style="background-image: url(<?php echo $featured ?>);"></span>
                </a><!-- .thumb-link -->

                <div class="hentry-inner">
                    <header class="entry-header">
                        <div class="entry-cats">
                            <div class="entry-cats"><a href="<?php esc_url(get_category_link($first_category)) ?>"
                                                       rel="category tag"><?php echo $first_category->name ?></a></div>
                        </div><!-- .entry-meta -->
                        <h2 class="entry-title"><a
                                href="<?php echo esc_url(get_permalink()); ?>"
                                rel="bookmark"><?php the_title() ?></a></h2>
                        <div class="entry-footer clear">
                            <div class="footer-meta"><span class="byline">By <a class="url fn n"
                                                                                href=""><?php the_author() ?></a></span><span
                                    class="posted-on"><a
                                        href="<?php echo esc_url(get_permalink()); ?>"
                                        rel="bookmark"><time class="entry-date published"
                                                             datetime="<?php echo get_the_time('c', get_the_ID()); ?>"><?php echo get_the_date(); ?></time><time
                                            class="updated"
                                            datetime="<?php echo get_the_modified_date('c', get_the_ID()); ?>"><?php echo get_the_modified_date(); ?></time></a></span>
                            </div>
                            <a class="more-link has-icon"
                               href="http://demo.themesharbor.com/aquene/fashion-the-essential-guide-to-spring-and-summer/"><span
                                    class="screen-reader-text">Continue Reading</span></a></div><!-- .entry-meta -->
                    </header><!-- .entry-header -->
                </div><!-- .hentry-inner -->
            </article>
            <!-- #post-## -->
        <?php endwhile;
        // Reset Post Data
        wp_reset_query();
        while ($postContent2->have_posts()): $postContent2->the_post();
            $featured = get_the_post_thumbnail_url($post->ID);
            $category = get_the_category();
            $first_category = $category[0];
            ?>
            <article id="post-<?php echo $post->ID; ?>"
                     class="post-<?php echo $post->ID; ?> post type-post status-publish format-standard has-post-thumbnail hentry category-lifestyle tag-colors tag-featured tag-international tag-style tag-tips">
                <a href="<?php echo esc_url(get_permalink()); ?>"
                   class="thumb-link ">
                <span class="featured-image has-background-cover has-animation"
                      style="background-image: url(<?php echo $featured ?>);"></span>
                </a><!-- .thumb-link -->

                <div class="hentry-inner">
                    <header class="entry-header">
                        <div class="entry-cats">
                            <div class="entry-cats"><a href="<?php esc_url(get_category_link($first_category)) ?>"
                                                       rel="category tag"><?php echo $first_category->name ?></a></div>
                        </div><!-- .entry-meta -->
                        <h2 class="entry-title"><a
                                href="<?php echo esc_url(get_permalink()); ?>"
                                rel="bookmark"><?php the_title() ?></a></h2>
                        <div class="entry-footer clear">
                            <div class="footer-meta"><span class="byline">By <a class="url fn n"
                                                                                href=""><?php the_author() ?></a></span><span
                                    class="posted-on"><a
                                        href="<?php echo esc_url(get_permalink()); ?>"
                                        rel="bookmark"><time class="entry-date published"
                                                             datetime="<?php echo get_the_time('c', get_the_ID()); ?>"><?php echo get_the_date(); ?></time><time
                                            class="updated"
                                            datetime="<?php echo get_the_modified_date('c', get_the_ID()); ?>"><?php echo get_the_modified_date(); ?></time></a></span>
                            </div>
                            <a class="more-link has-icon"
                               href="http://demo.themesharbor.com/aquene/fashion-the-essential-guide-to-spring-and-summer/"><span
                                    class="screen-reader-text">Continue Reading</span></a></div><!-- .entry-meta -->
                    </header><!-- .entry-header -->
                </div><!-- .hentry-inner -->
            </article>
        <?php endwhile;
        ?>
        <?php
        echo $after_widget;
    }
}

/**************************************************************************************/

/**
 * Featured service widget to show pages.
 */
class aquene_secondary_section_widget extends WP_Widget
{
    function __construct()
    {
        $widget_ops = array(
            'classname' => 'widget_featured_block',
            'description' => __('Display Secondary Section.', 'aquene'),
            'customize_selective_refresh' => true,
        );
        $control_ops = array('width' => 200, 'height' => 250);
        parent::__construct(false, $name = __('Aquene Secondary Section', 'aquene'), $widget_ops, $control_ops);
    }

    function form($instance)
    {
        for ($i = 0; $i < 3; $i++) {
            $var = 'page_id' . $i;
            $defaults[$var] = '';
        }
        $instance = wp_parse_args((array)$instance, $defaults);
        for ($i = 0; $i < 3; $i++) {
            $var = 'page_id' . $i;
            $var = absint($instance[$var]);
        }
        ?>
        <?php for ($i = 0; $i < 3; $i++) { ?>
        <p>
            <label for="<?php echo $this->get_field_id(key($defaults)); ?>"><?php _e('Post', 'aquene'); ?>:</label>
            <select style="width: 85%" name="<?php echo $this->get_field_name(key($defaults)) ?>" id="">
                <option value="0"><?php _e('&mdash; Select &mdash;'); ?></option>
                <?php
                do_action('qrPost', -1, 1, null);
                ?>
                <?php if (have_posts()) : ?>

                    <?php while (have_posts()) : the_post(); ?>

                        <option <?php echo ($instance[key($defaults)] == get_the_ID()) ? 'selected' : '' ?>
                            value="<?php echo get_the_ID(); ?>"><?php echo get_the_title(); ?></option>

                    <?php endwhile; ?>

                <?php endif;
                wp_reset_query(); ?>
            </select>
        </p>
        <?php
        next($defaults);// forwards the key of $defaults array
    }
    }

    function update($new_instance, $old_instance)
    {
        $instance = $old_instance;
        for ($i = 0; $i < 3; $i++) {
            $var = 'page_id' . $i;
            $instance[$var] = absint($new_instance[$var]);
        }

        return $instance;
    }

    function widget($args, $instance)
    {
        extract($args);
        extract($instance);
        global $post;
        $page_array = array();
        for ($i = 0; $i < 3; $i++) {
            $var = 'page_id' . $i;
            $page_id = isset($instance[$var]) ? $instance[$var] : '';

            if (!empty($page_id)) {
                array_push($page_array, $page_id);
            }// Push the page id in the array
        }

        $get_featured_pages = new WP_Query(array(
            'posts_per_page' => -1,
            'post_type' => array('post'),
            'post__in' => !empty($page_array) ? $page_array : array(0),
            'orderby' => 'post__in'
        ));
        echo $before_widget; ?>
        <?php
        while ($get_featured_pages->have_posts()):$get_featured_pages->the_post();
            $featured = get_the_post_thumbnail_url($post->ID, 'featured-thumbnail');
            ?>
            <article id="post-<?php $post->ID; ?>"
                     class="post-<?php $post->ID; ?> post type-post status-publish format-standard has-post-thumbnail hentry tag-featured">
                <div class="hentry-inner">
                    <a href="<?php echo esc_url(get_permalink()); ?>" class="thumb-link has-animation">
                        <img width="200" height="200" src="<?php echo $featured ?>" alt="<?php the_title() ?>"
                             title="<?php the_title() ?>">
                    </a><!-- .thumb-link -->

                    <header class="entry-header">
                        <h2 class="entry-title">
                            <a href="<?php echo esc_url(get_permalink()); ?>" rel="bookmark"><?php the_title() ?></a>
                        </h2>
                        <div class="entry-footer clear">
                            <div class="footer-meta"><span class="byline">By <a class="url fn n"
                                                                                href=""><?php the_author() ?></a></span><span
                                    class="posted-on"><a href="<?php echo esc_url(get_permalink()); ?>" rel="bookmark"><time
                                            class="entry-date published"
                                            datetime="<?php echo get_the_time('c', get_the_ID()); ?>"><?php echo get_the_date(); ?></time><time
                                            class="updated"
                                            datetime="<?php echo get_the_modified_date('c', get_the_ID()); ?>"><?php echo get_the_modified_date(); ?></time></a></span>
                            </div>
                            <a class="more-link has-icon"
                               href="http://demo.themesharbor.com/aquene/traveling-to-these-cities-is-getting-more-expensive/"><span
                                    class="screen-reader-text"><?php _e('Continue Reading', 'aquene'); ?></span></a>
                        </div><!-- .entry-footer -->
                    </header><!-- .entry-header -->
                </div><!-- .hentry-inner -->
            </article>
        <?php endwhile;
        // Reset Post Data
        wp_reset_query();
        ?>
        <?php
        echo $after_widget;
    }
}

/**************************************************************************************/

?>