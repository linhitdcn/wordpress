<?php
/**
 * Admin View: Page - Installer
 */

if (!defined('ABSPATH')) {
    exit;
}

global $current_filter;

$current_filter = empty($_GET['browse']) ? 'welcome' : sanitize_title($_GET['browse']);
$demo_filter_links = apply_filters('demo_importer_filter_links_array', array(
    'welcome' => __('Welcome', 'aquene'),
    'preview' => __('Theme Demos', 'aquene'),
));
?>
<div class="wrap demo-importer">
    <div class="wp-filter hide-if-no-js">

        <ul class="filter-links">
            <?php
            foreach ($demo_filter_links as $name => $label) {
                echo '<li><a href="' . admin_url('themes.php?page=demo-importer&browse=' . $name) . '" class="demo-tab ' . ($current_filter == $name ? 'current' : '') . '">' . $label . '</a></li>';
            }
            ?>
        </ul>
    </div>
    <?php if ('welcome' === $current_filter) : ?>
        <div id="welcome-panel" class="welcome-panel">
            <div class="welcome-panel-content">
                <h2><?php echo _e('Welcome to theme ', 'aquene') . wp_get_theme(); ?></h2>
                <h3><?php _e('Get Started', 'aquene'); ?></h3>
                <div class="welcome-panel-column-container">
                    <div class="welcome-panel-column">
                        <ul>
                            <li><?php printf(__('1. Visit <a href="%s" target="_blank"><strong>this page</strong></a> and download the theme demo file.', 'aquene'), esc_url(self_admin_url('themes.php?page=demo-importer&browse=preview'))); ?></li>
                            <li><?php _e('2. Install & Active plugin <b>One Click Demo Import.</b>', 'aquene'); ?></li>
                            <li><?php _e('3. Go to page <strong>Import Demo Data.</strong>', 'aquene'); ?></li>
                            <li><?php _e('4. Choose a <b>XML file</b> for content import.', 'aquene'); ?></li>
                            <li><?php _e('5. Click on the <strong>Import</strong> button and wait for few minutes. Done!', 'aquene'); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="welcome-panel-iframe-video">
                <div class="welcome-panel-iframe-video-inner">
                    <a href="https://youtu.be/Gg_Le6AW3fA" target="_blank"
                       class="themegrill-demo-importer-guided-tour-embed" data-video_id="rhiybsv3vUU">
                        <img src="https://img.youtube.com/vi/Gg_Le6AW3fA/sddefault.jpg" width="560" height="315"/>
                    </a>
                </div>
            </div>
        </div>
    <?php else : ?>
        <h2 class="screen-reader-text hide-if-no-js"><?php _e('Available demos list', 'aquene'); ?></h2>
        <?php if (in_array($current_filter, array('preview'))) : ?>
            <div class="theme-browser rendered">
                <div class="themes wp-clearfix">
                    <?php foreach ($demos as $demo) : ?>
                        <div class="theme" tabindex="0">
                            <a target="_blank" href="<?php echo esc_url($demo['actions']['preview_url']); ?>">
                                <?php if ($demo['screenshot']) : ?>
                                    <div class="theme-screenshot">
                                        <img src="<?php echo esc_url($demo['screenshot']); ?>" alt=""/>
                                    </div>
                                <?php else : ?>
                                    <div class="theme-screenshot blank"></div>
                                <?php endif; ?>
                                <span class="more-details"><?php _e('Demo Preview', 'aquene'); ?></span>
                            </a>
                            <div class="theme-author"><?php
                                /* translators: %s: Demo author name */
                                printf(__('By %s', 'aquene'), $demo['author']);
                                ?></div>

                            <div class="theme-id-container">
                                <h3 class="theme-name"><?php echo esc_html($demo['name']); ?></h3>

                                <div class="theme-actions">
                                    <?php
                                    /* translators: %s: Demo name */
                                    $aria_label = sprintf(_x('Download %s', 'demo', 'aquene'), esc_attr($demo['name']));
                                    ?>
                                    <a download class="button button-primary demo-download"
                                       data-name="<?php echo esc_attr($demo['name']); ?>"
                                       href="<?php echo esc_url($demo['actions']['download_url'])?>"
                                       aria-label="<?php echo esc_attr($aria_label); ?>"><?php _e('Download', 'aquene'); ?></a>

                                    <a class="button button-secondary demo-preview" target="_blank"
                                       href="<?php echo esc_url($demo['actions']['preview_url']); ?>"><?php _e('Preview', 'aquene'); ?></a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>
    <?php endif; ?>
</div>

