</div><!-- #end-content -->
<footer id="colophon" class="site-footer" role="contentinfo">
    <div class="footer-top footer-section">
        <div class="footer-branding">
            <?php dynamic_sidebar( 'aquene_footer_site_title' ); ?>
        </div>
        <!-- .footer-branding -->

        <nav class="jetpack-social-navigation jetpack-social-navigation-genericons" role="navigation"
             aria-label="Social Links Menu">
            <?php
            if (has_nav_menu('footer')) {
                wp_nav_menu(array(
                    'menu'=> 'Aquene Social Menu',
                    'theme_location' => 'footer',
                   // 'walker' => new description_walker(),
                    'container_class' => 'menu-social-menu-container'
                ));
            }
            ?>
        </nav><!-- .jetpack-social-navigation -->
    </div><!-- .footer-top -->

    <div class="widget-area footer-section clear">

        <?php dynamic_sidebar( 'aquene_footer_sidebar_one' ); ?>
        <?php dynamic_sidebar( 'aquene_footer_sidebar_two' ); ?>
        <?php dynamic_sidebar( 'aquene_footer_sidebar_three' ); ?>
        <?php dynamic_sidebar( 'aquene_footer_sidebar_four' ); ?>

    </div><!-- .widget-area -->

    <div class="footer-bottom footer-section">
        <nav class="site-navigation footer-navigation" role="navigation" aria-label="Footer Navigation">
            <?php
            if (has_nav_menu('footer')) {
                wp_nav_menu(array(
                    'menu'=> 'Aquene Bottom Menu',
                    'theme_location' => 'footer',
                    'container_class' => 'menu-bottom-menu-container'
                ));
            }
            ?>
        </nav><!-- .footer-navigation -->

        <div class="site-info">
            <?php dynamic_sidebar( 'aquene_footer_sidebar_site_info' ); ?>
        </div><!-- .site-info -->
    </div><!-- .footer-bottom -->
</footer>
</div><!-- end-page-->
<?php wp_footer(); ?>
</body>
</html>
