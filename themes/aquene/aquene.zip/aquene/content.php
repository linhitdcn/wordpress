<?php
$urlImg = wp_get_attachment_url(get_post_thumbnail_id(get_the_ID()), 'thumbnail');
$category = get_the_category();
$first_category = $category[0];
?>
<article id="post-<?php the_ID(); ?>"
         class="post-295 post type-post status-publish format-standard has-post-thumbnail hentry category-lifestyle tag-colors tag-reward tag-style tag-tips">
    <a href="<?php echo esc_url(get_permalink()); ?>" class="thumb-link">
        <span class="featured-image has-background-cover has-animation"
              style="background-image: url(<?php echo esc_url($urlImg) ?>)"></span>
    </a><!-- .thumb-link -->

    <div class="hentry-inner">
        <header class="entry-header primary-font">
            <div class="entry-cats">
                <a href="<?php esc_url(get_category_link($first_category)) ?>"
                   rel="category tag"><?php echo $first_category->name ?></a>
            </div>
            <h2 class="entry-title"><?php echo sprintf('<a href="%s" rel="bookmark">%s</a>', get_permalink(), get_the_title()) ?></h2>
        </header><!-- .entry-header -->

        <footer class="entry-footer clear">
            <div class="footer-meta">
                <span class="byline">By <a class="url fn n"
                                           href="<?php echo get_author_posts_url($post->post_author); ?>"><?php the_author() ?></a></span>
                <span class="posted-on"><a
                        href="<?php echo esc_url(get_permalink()); ?>"
                        rel="bookmark">
						<time class="entry-date published" datetime="<?php echo get_the_time('c', get_the_ID()); ?>"><?php echo get_the_date(); ?></time>
						<time class="updated" datetime="<?php echo get_the_modified_date('c',  get_the_ID()); ?>"><?php echo get_the_modified_date(); ?></time></a>
				</span>
            </div>
            <a class="more-link has-icon" href="<?php echo esc_url(get_permalink()); ?>">
                <span class="screen-reader-text">Continue Reading</span>
            </a>
        </footer><!-- .entry-footer -->
    </div><!-- .hentry-inner -->
</article><!-- #post-## -->
