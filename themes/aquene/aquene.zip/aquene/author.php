<?php
/**
 * The template for displaying Archive page.
 *
 * @package ThemeGrill
 * @subpackage Spacious
 * @since Spacious 1.0
 */
get_header(); ?>
<?php
global $wp_query;
$curauth = $wp_query->get_queried_object();
?>
<div id="primary" class="content-area">
    <header class="page-header clear">
        <div class="header-inner">
            <h1 class="page-title"><span><?php echo __('Author', 'aquene') ?>: </span><span><?php echo $curauth->display_name ?></span></h1>
            <div class="archive-description">
               <?php echo $curauth->description; ?>
            </div>
        </div><!-- .header-inner -->
        <?php echo get_avatar($curauth->ID,192,'','',array('class'=>'avatar photo','id'=>'')); ?>
    </header>
    <main id="main" class="site-main archive-grid clear" role="main">
        <?php
        global $wp_query;
        $text_older_posts = get_option('aquene_text_older_posts')? get_option('aquene_text_older_posts'): 'Older posts';
        ?>
        <?php if (have_posts()) : ?>

            <?php while (have_posts()) : the_post(); ?>

                <?php get_template_part('content'); ?>

            <?php endwhile; ?>

        <?php else : ?>

            <?php get_template_part('no-results'); ?>

        <?php endif; ?>
        <span class="infinite-loader">
            <div class="spinner" role="progressbar"></div>
        </span>
        <?php if ($wp_query->max_num_pages > 1) : ?>
            <div id="infinite-handle" onclick="loadMore(this);return false;"><span><button> <?php echo $text_older_posts; ?></button></span>
            </div>
        <?php endif; ?>
    </main><!-- #main -->
</div>

<?php get_footer(); ?>
