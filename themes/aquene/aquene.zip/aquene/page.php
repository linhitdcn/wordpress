<?php
/**
 * Theme Page Section for our theme.
 *
 * @package ThemeGrill
 * @subpackage Spacious
 * @since Spacious 1.0
 */
get_header(); ?>

<div id="primary" class="content-area">
    <main id="main" class="site-main" role="main">
        <article id="post-2" class="post-2 page type-page status-publish hentry">
            <header class="entry-header hentry-wrapper">
                    <h1 class="entry-title"><?php single_post_title(); ?></h1>
            </header>
            <div class="hentry-inner hentry-wrapper">
                <div class="entry-content">
                    <?php while ( have_posts() ) : the_post(); ?>
                        <?php the_content(); ?>
                    <?php endwhile; ?>
                </div>
            </div>
        </article>
    </main>
</div>

<?php get_footer(); ?>
