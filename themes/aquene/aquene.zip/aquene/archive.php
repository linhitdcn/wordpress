<?php
/**
 * The template for displaying Archive page.
 *
 * @package linhitdcn
 * @subpackage aquene
 * @since aquene 1.0
 */
get_header(); ?>
<div id="primary" class="content-area">
    <header class="page-header">
        <h1 class="page-title"><span><?php echo __('Month', 'aquene') ?>: </span><?php single_month_title(' '); ?></h1>
    </header>
    <main id="main" class="site-main archive-grid clear" role="main">
        <?php
        global $wp_query;
        $text_older_posts = get_option('aquene_text_older_posts')? get_option('aquene_text_older_posts'): 'Older posts';
        ?>
        <?php if (have_posts()) : ?>

            <?php while (have_posts()) : the_post(); ?>

                <?php get_template_part('content'); ?>

            <?php endwhile; ?>

        <?php else : ?>

            <?php get_template_part('no-results'); ?>

        <?php endif; ?>
        <span class="infinite-loader">
            <div class="spinner" role="progressbar"></div>
        </span>
        <?php if ($wp_query->max_num_pages > 1) : ?>
            <div id="infinite-handle" onclick="loadMore(this);return false;"><span><button> <?php echo $text_older_posts; ?></button></span>
            </div>
        <?php endif; ?>
    </main><!-- #main -->
</div>

<?php get_footer(); ?>
